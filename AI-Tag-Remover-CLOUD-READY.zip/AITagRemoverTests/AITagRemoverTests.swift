import AVFoundation
import CoreVideo
import ImageIO
import UniformTypeIdentifiers
import XCTest
@testable import AITagRemover

final class AITagRemoverTests: XCTestCase {
    func testImageCleanerRemovesSensitiveMetadataAndProvenanceMarker() throws {
        let sourceURL = temporaryURL(extension: "jpg")
        let destinationURL = temporaryURL(extension: "jpg")
        addTeardownBlock {
            try? FileManager.default.removeItem(at: sourceURL)
            try? FileManager.default.removeItem(at: destinationURL)
        }

        try makeJPEGWithMetadata(at: sourceURL)

        let before = try MetadataInspector.inspectImage(at: sourceURL)
        XCTAssertFalse(before.isClean)
        XCTAssertGreaterThan(before.totalTagCount, 0)

        _ = try ImageMetadataCleaner.clean(
            sourceURL: sourceURL,
            destinationURL: destinationURL
        )

        let after = try MetadataInspector.inspectImage(at: destinationURL)
        XCTAssertTrue(after.isClean)

        let originalSource = try XCTUnwrap(CGImageSourceCreateWithURL(sourceURL as CFURL, nil))
        let cleanedSource = try XCTUnwrap(CGImageSourceCreateWithURL(destinationURL as CFURL, nil))
        XCTAssertEqual(
            CGImageSourceGetCount(originalSource),
            CGImageSourceGetCount(cleanedSource)
        )
        let originalProperties = CGImageSourceCopyPropertiesAtIndex(originalSource, 0, nil) as NSDictionary?
        let cleanedProperties = CGImageSourceCopyPropertiesAtIndex(cleanedSource, 0, nil) as NSDictionary?
        XCTAssertEqual(
            originalProperties?[kCGImagePropertyPixelWidth] as? NSNumber,
            cleanedProperties?[kCGImagePropertyPixelWidth] as? NSNumber
        )
        XCTAssertEqual(
            originalProperties?[kCGImagePropertyPixelHeight] as? NSNumber,
            cleanedProperties?[kCGImagePropertyPixelHeight] as? NSNumber
        )
    }

    func testMetadataClassifierRecognizesPrivacyCategories() {
        XCTAssertEqual(MetadataInspector.category(for: "quicktime.location.ISO6709"), .location)
        XCTAssertEqual(MetadataInspector.category(for: "exif.DateTimeOriginal"), .captureDates)
        XCTAssertEqual(MetadataInspector.category(for: "tiff.CameraModel"), .camera)
        XCTAssertEqual(MetadataInspector.category(for: "iptc.Copyright"), .attribution)
        XCTAssertEqual(MetadataInspector.category(for: "xmp.provenance.c2pa"), .editing)
    }

    func testVideoCleanerRemovesContainerMetadata() async throws {
        let sourceURL = temporaryURL(extension: "mov")
        addTeardownBlock { try? FileManager.default.removeItem(at: sourceURL) }
        try await makeVideoWithMetadata(at: sourceURL)

        let before = try await MetadataInspector.inspectVideo(at: sourceURL)
        XCTAssertFalse(before.isClean)

        let result = try await VideoMetadataCleaner.clean(
            sourceURL: sourceURL,
            outputDirectory: FileManager.default.temporaryDirectory
        )
        addTeardownBlock { try? FileManager.default.removeItem(at: result.outputURL) }

        let after = try await MetadataInspector.inspectVideo(at: result.outputURL)
        XCTAssertTrue(after.isClean)
        let outputDuration = try await AVURLAsset(url: result.outputURL).load(.duration)
        XCTAssertGreaterThan(outputDuration.seconds, 0)
    }

    private func temporaryURL(extension fileExtension: String) -> URL {
        FileManager.default.temporaryDirectory
            .appendingPathComponent("AITagRemoverTests-\(UUID().uuidString)")
            .appendingPathExtension(fileExtension)
    }

    private func makeJPEGWithMetadata(at url: URL) throws {
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let context = try XCTUnwrap(CGContext(
            data: nil,
            width: 8,
            height: 8,
            bitsPerComponent: 8,
            bytesPerRow: 32,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ))
        context.setFillColor(red: 0.8, green: 0.2, blue: 0.5, alpha: 1)
        context.fill(CGRect(x: 0, y: 0, width: 8, height: 8))
        let image = try XCTUnwrap(context.makeImage())
        let destination = try XCTUnwrap(CGImageDestinationCreateWithURL(
            url as CFURL,
            UTType.jpeg.identifier as CFString,
            1,
            nil
        ))

        let properties: [CFString: Any] = [
            kCGImagePropertyGPSDictionary: [
                kCGImagePropertyGPSLatitude: 41.881_832,
                kCGImagePropertyGPSLatitudeRef: "N",
                kCGImagePropertyGPSLongitude: 87.623_177,
                kCGImagePropertyGPSLongitudeRef: "W"
            ],
            kCGImagePropertyExifDictionary: [
                kCGImagePropertyExifDateTimeOriginal: "2026:09:03 10:00:00"
            ],
            kCGImagePropertyTIFFDictionary: [
                kCGImagePropertyTIFFMake: "Test Camera",
                kCGImagePropertyTIFFModel: "Private Model",
                kCGImagePropertyTIFFSoftware: "Editing Tool"
            ],
            kCGImagePropertyIPTCDictionary: [
                kCGImagePropertyIPTCCopyrightNotice: "Private Author"
            ]
        ]
        CGImageDestinationAddImage(destination, image, properties as CFDictionary)
        XCTAssertTrue(CGImageDestinationFinalize(destination))

        // A stand-in for a file-level provenance box that Image I/O doesn't expose
        // as ordinary EXIF/XMP. A fresh-container rebuild must omit it.
        let file = try FileHandle(forWritingTo: url)
        try file.seekToEnd()
        try file.write(contentsOf: Data("c2pa".utf8))
        try file.close()
    }

    private func makeVideoWithMetadata(at url: URL) async throws {
        let writer = try AVAssetWriter(outputURL: url, fileType: .mov)
        let input = AVAssetWriterInput(
            mediaType: .video,
            outputSettings: [
                AVVideoCodecKey: AVVideoCodecType.h264,
                AVVideoWidthKey: 32,
                AVVideoHeightKey: 32
            ]
        )
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: input,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: 32,
                kCVPixelBufferHeightKey as String: 32
            ]
        )

        let title = AVMutableMetadataItem()
        title.identifier = .quickTimeMetadataTitle
        title.value = "Private title" as NSString
        title.dataType = kCMMetadataBaseDataType_UTF8 as String
        writer.metadata = [title]

        XCTAssertTrue(writer.canAdd(input))
        writer.add(input)
        XCTAssertTrue(writer.startWriting())
        writer.startSession(atSourceTime: .zero)

        var buffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            32,
            32,
            kCVPixelFormatType_32BGRA,
            nil,
            &buffer
        )
        XCTAssertEqual(status, kCVReturnSuccess)
        let pixelBuffer = try XCTUnwrap(buffer)
        XCTAssertTrue(input.isReadyForMoreMediaData)
        XCTAssertTrue(adaptor.append(pixelBuffer, withPresentationTime: .zero))
        XCTAssertTrue(adaptor.append(pixelBuffer, withPresentationTime: CMTime(value: 1, timescale: 1)))
        input.markAsFinished()

        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            writer.finishWriting { continuation.resume() }
        }
        if let error = writer.error { throw error }
        XCTAssertEqual(writer.status, .completed)
    }
}
