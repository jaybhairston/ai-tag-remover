import SwiftUI

@main
struct AITagRemoverApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
                .tint(AppTheme.plum)
        }
    }
}
