import Foundation
import ImageIO
import PhotosUI
import SwiftUI
import UniformTypeIdentifiers

@MainActor
final class CleanerViewModel: ObservableObject {
    @Published var pickerItems: [PhotosPickerItem] = []
    @Published private(set) var mediaItems: [MediaItem] = []
    @Published private(set) var isImporting = false
    @Published private(set) var isCleaning = false
    @Published private(set) var isSaving = false
    @Published var isSharePresented = false
    @Published var alertMessage: String?

    private let workDirectory: URL

    init() {
        workDirectory = FileManager.default.temporaryDirectory
            .appendingPathComponent("AITagRemover-\(UUID().uuidString)", isDirectory: true)
        try? FileManager.default.createDirectory(
            at: workDirectory,
            withIntermediateDirectories: true,
            attributes: nil
        )
    }

    var isBusy: Bool {
        isImporting || isCleaning || isSaving
    }

    var cleanedURLs: [URL] {
        mediaItems.compactMap(\.cleanedURL)
    }

    var totalDetectedTags: Int {
        mediaItems.reduce(0) { $0 + $1.originalReport.totalTagCount }
    }

    var allItemsClean: Bool {
        !mediaItems.isEmpty && mediaItems.allSatisfy {
            if case .clean = $0.status { return true }
            if case .saved = $0.status { return true }
            return false
        }
    }

    var hasFailures: Bool {
        mediaItems.contains {
            if case .failed = $0.status { return true }
            return false
        }
    }

    func importSelections(_ selections: [PhotosPickerItem]) async {
        guard !selections.isEmpty else { return }
        clear(removePickerSelection: false)
        isImporting = true
        defer { isImporting = false }

        var failures = 0
        for selection in selections {
            do {
                let item = try await importSelection(selection)
                mediaItems.append(item)
            } catch {
                failures += 1
            }
        }

        if failures > 0 {
            alertMessage = failures == 1
                ? "One item could not be imported."
                : "\(failures) items could not be imported."
        }
    }

    func cleanAll() async {
        guard !mediaItems.isEmpty, !isBusy else { return }
        isCleaning = true
        defer { isCleaning = false }

        let idsToClean = mediaItems.compactMap { item -> UUID? in
            switch item.status {
            case .clean, .saved:
                return nil
            default:
                return item.id
            }
        }

        for id in idsToClean {
            guard let index = mediaItems.firstIndex(where: { $0.id == id }) else { continue }
            mediaItems[index].status = .cleaning
            let item = mediaItems[index]

            do {
                let result: CleaningResult
                switch item.kind {
                case .image:
                    let sourceExtension = item.sourceURL.pathExtension.isEmpty
                        ? "jpg"
                        : item.sourceURL.pathExtension
                    let destinationURL = workDirectory
                        .appendingPathComponent("aitagremover-clean-\(UUID().uuidString)")
                        .appendingPathExtension(sourceExtension)
                    result = try await Task.detached(priority: .userInitiated) {
                        try ImageMetadataCleaner.clean(
                            sourceURL: item.sourceURL,
                            destinationURL: destinationURL
                        )
                    }.value
                case .video:
                    result = try await VideoMetadataCleaner.clean(
                        sourceURL: item.sourceURL,
                        outputDirectory: workDirectory
                    )
                }

                if let currentIndex = mediaItems.firstIndex(where: { $0.id == id }) {
                    mediaItems[currentIndex].cleanedURL = result.outputURL
                    mediaItems[currentIndex].status = .clean
                }
            } catch {
                if let currentIndex = mediaItems.firstIndex(where: { $0.id == id }) {
                    mediaItems[currentIndex].status = .failed(error.localizedDescription)
                }
            }
        }

        let failureCount = mediaItems.filter {
            if case .failed = $0.status { return true }
            return false
        }.count
        if failureCount > 0 {
            alertMessage = failureCount == 1
                ? "One item could not be verified as clean."
                : "\(failureCount) items could not be verified as clean."
        }
    }

    func saveAll() async {
        let savable = mediaItems.compactMap { item -> (url: URL, kind: MediaKind)? in
            guard let url = item.cleanedURL else { return nil }
            return (url, item.kind)
        }
        guard !savable.isEmpty, !isBusy else { return }

        isSaving = true
        defer { isSaving = false }
        do {
            try await PhotoLibrarySaver.save(savable)
            for index in mediaItems.indices where mediaItems[index].cleanedURL != nil {
                mediaItems[index].status = .saved
            }
            alertMessage = savable.count == 1
                ? "Clean copy saved to Photos."
                : "\(savable.count) clean copies saved to Photos."
        } catch {
            alertMessage = error.localizedDescription
        }
    }

    func clear(removePickerSelection: Bool = true) {
        for item in mediaItems {
            try? FileManager.default.removeItem(at: item.sourceURL)
            if let cleanedURL = item.cleanedURL {
                try? FileManager.default.removeItem(at: cleanedURL)
            }
        }
        mediaItems.removeAll()
        if removePickerSelection {
            pickerItems.removeAll()
        }
    }

    private func importSelection(_ selection: PhotosPickerItem) async throws -> MediaItem {
        let isVideo = selection.supportedContentTypes.contains { $0.conforms(to: .movie) }
        let kind: MediaKind = isVideo ? .video : .image
        let sourceURL: URL

        if isVideo {
            guard let movie = try await selection.loadTransferable(type: PickedMovie.self) else {
                throw MediaCleaningError.importFailed
            }
            sourceURL = movie.url
        } else {
            guard let data = try await selection.loadTransferable(type: Data.self) else {
                throw MediaCleaningError.importFailed
            }
            let contentType = selection.supportedContentTypes.first { $0.conforms(to: .image) }
            let fileExtension = contentType?.preferredFilenameExtension ?? imageExtension(for: data) ?? "jpg"
            sourceURL = workDirectory
                .appendingPathComponent("aitagremover-import-\(UUID().uuidString)")
                .appendingPathExtension(fileExtension)
            try data.write(to: sourceURL, options: .atomic)
        }

        let report: MetadataReport
        switch kind {
        case .image:
            report = try await Task.detached(priority: .userInitiated) {
                try MetadataInspector.inspectImage(at: sourceURL)
            }.value
        case .video:
            report = try await MetadataInspector.inspectVideo(at: sourceURL)
        }

        let thumbnail = await ThumbnailLoader.thumbnail(for: sourceURL, kind: kind)
        return MediaItem(
            sourceURL: sourceURL,
            kind: kind,
            filename: sourceURL.lastPathComponent,
            originalReport: report,
            thumbnail: thumbnail
        )
    }

    private func imageExtension(for data: Data) -> String? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let typeIdentifier = CGImageSourceGetType(source) as String?,
              let type = UTType(typeIdentifier)
        else { return nil }
        return type.preferredFilenameExtension
    }
}
