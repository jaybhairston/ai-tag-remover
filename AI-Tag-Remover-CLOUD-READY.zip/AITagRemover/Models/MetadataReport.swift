import Foundation

enum MetadataCategory: String, CaseIterable, Hashable, Sendable {
    case location = "Location"
    case captureDates = "Capture dates"
    case camera = "Camera & lens"
    case attribution = "Names & captions"
    case editing = "Editing & XMP"
    case other = "Other hidden data"

    var systemImage: String {
        switch self {
        case .location: "location.fill"
        case .captureDates: "calendar"
        case .camera: "camera.aperture"
        case .attribution: "person.text.rectangle"
        case .editing: "wand.and.stars"
        case .other: "tag.fill"
        }
    }
}

struct MetadataReport: Equatable, Sendable {
    var counts: [MetadataCategory: Int] = [:]

    var totalTagCount: Int {
        counts.values.reduce(0, +)
    }

    var categories: [MetadataCategory] {
        MetadataCategory.allCases.filter { (counts[$0] ?? 0) > 0 }
    }

    var isClean: Bool {
        totalTagCount == 0
    }

    mutating func add(_ category: MetadataCategory, count: Int = 1) {
        guard count > 0 else { return }
        counts[category, default: 0] += count
    }
}

struct CleaningResult: Sendable {
    let outputURL: URL
    let removedReport: MetadataReport
}

enum MediaCleaningError: LocalizedError {
    case unreadableImage
    case unsupportedImageFormat
    case imageWriteFailed
    case metadataVerificationFailed
    case videoExportUnavailable
    case unsupportedVideoFormat
    case videoExportFailed(String)
    case permissionDenied
    case importFailed

    var errorDescription: String? {
        switch self {
        case .unreadableImage:
            "This photo could not be read."
        case .unsupportedImageFormat:
            "This photo format cannot be cleaned on this device."
        case .imageWriteFailed:
            "The cleaned photo could not be created."
        case .metadataVerificationFailed:
            "AI Tag Remover could not verify that the private metadata was removed."
        case .videoExportUnavailable:
            "This video cannot be exported on this device."
        case .unsupportedVideoFormat:
            "This video format cannot be cleaned on this device."
        case .videoExportFailed(let reason):
            "The video could not be cleaned. \(reason)"
        case .permissionDenied:
            "Allow AI Tag Remover to add photos in Settings, then try again."
        case .importFailed:
            "One of the selected items could not be imported."
        }
    }
}
