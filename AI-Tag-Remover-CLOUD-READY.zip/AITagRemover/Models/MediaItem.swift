import Foundation
import UIKit

enum MediaKind: String, Sendable {
    case image
    case video

    var title: String {
        switch self {
        case .image: "Photo"
        case .video: "Video"
        }
    }

    var systemImage: String {
        switch self {
        case .image: "photo"
        case .video: "video"
        }
    }
}

enum MediaStatus: Equatable {
    case ready
    case cleaning
    case clean
    case saved
    case failed(String)
}

struct MediaItem: Identifiable {
    let id: UUID
    let sourceURL: URL
    let kind: MediaKind
    let filename: String
    let originalReport: MetadataReport
    var thumbnail: UIImage?
    var cleanedURL: URL?
    var status: MediaStatus

    init(
        id: UUID = UUID(),
        sourceURL: URL,
        kind: MediaKind,
        filename: String,
        originalReport: MetadataReport,
        thumbnail: UIImage? = nil,
        cleanedURL: URL? = nil,
        status: MediaStatus = .ready
    ) {
        self.id = id
        self.sourceURL = sourceURL
        self.kind = kind
        self.filename = filename
        self.originalReport = originalReport
        self.thumbnail = thumbnail
        self.cleanedURL = cleanedURL
        self.status = status
    }
}
