import CoreTransferable
import Foundation
import UniformTypeIdentifiers

struct PickedMovie: Transferable {
    let url: URL

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { movie in
            SentTransferredFile(movie.url)
        } importing: { received in
            let sourceExtension = received.file.pathExtension.isEmpty ? "mov" : received.file.pathExtension
            let copyURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("aitagremover-import-\(UUID().uuidString)")
                .appendingPathExtension(sourceExtension)
            try FileManager.default.copyItem(at: received.file, to: copyURL)
            return PickedMovie(url: copyURL)
        }
    }
}
