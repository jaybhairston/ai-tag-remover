import SwiftUI

enum AppTheme {
    static let plum = Color(red: 0.36, green: 0.08, blue: 0.29)
    static let rose = Color(red: 0.76, green: 0.20, blue: 0.42)
    static let apricot = Color(red: 1.00, green: 0.55, blue: 0.38)
    static let ink = Color(red: 0.14, green: 0.10, blue: 0.13)
    static let canvas = Color(red: 0.98, green: 0.96, blue: 0.97)

    static let brandGradient = LinearGradient(
        colors: [plum, rose, apricot],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
}

struct CardStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(18)
            .background(.white.opacity(0.92), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .stroke(.white.opacity(0.9), lineWidth: 1)
            }
            .shadow(color: AppTheme.plum.opacity(0.08), radius: 24, y: 10)
    }
}

extension View {
    func cardStyle() -> some View {
        modifier(CardStyle())
    }
}
