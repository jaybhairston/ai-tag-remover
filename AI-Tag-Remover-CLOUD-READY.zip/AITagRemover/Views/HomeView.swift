import PhotosUI
import SwiftUI

struct HomeView: View {
    @StateObject private var model = CleanerViewModel()
    @State private var isPrivacyPresented = false

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.canvas.ignoresSafeArea()
                Circle()
                    .fill(AppTheme.rose.opacity(0.10))
                    .frame(width: 330, height: 330)
                    .blur(radius: 20)
                    .offset(x: 160, y: -310)
                    .accessibilityHidden(true)

                ScrollView {
                    VStack(spacing: 24) {
                        header
                        if model.mediaItems.isEmpty {
                            emptyState
                        } else {
                            selectedState
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    .padding(.bottom, 32)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
        .onChange(of: model.pickerItems) { _, selections in
            Task { await model.importSelections(selections) }
        }
        .sheet(isPresented: $isPrivacyPresented) {
            PrivacyView()
        }
        .sheet(isPresented: $model.isSharePresented) {
            ShareSheet(items: model.cleanedURLs)
        }
        .alert("AI Tag Remover", isPresented: alertBinding) {
            Button("OK", role: .cancel) { model.alertMessage = nil }
        } message: {
            Text(model.alertMessage ?? "")
        }
    }

    private var header: some View {
        HStack {
            HStack(spacing: 10) {
                ZStack {
                    AppTheme.brandGradient
                    Image(systemName: "photo.badge.checkmark")
                        .font(.system(size: 19, weight: .semibold))
                        .foregroundStyle(.white)
                }
                .frame(width: 40, height: 40)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                Text("AI Tag Remover")
                    .font(.title3.weight(.bold))
                    .foregroundStyle(AppTheme.ink)
            }

            Spacer()
            Button {
                isPrivacyPresented = true
            } label: {
                Image(systemName: "info.circle")
                    .font(.title3)
                    .frame(width: 44, height: 44)
            }
            .accessibilityLabel("Privacy information")
        }
    }

    private var emptyState: some View {
        VStack(spacing: 24) {
            VStack(spacing: 14) {
                Text("Remove hidden tags.\nKeep the look.")
                    .font(.system(size: 38, weight: .bold, design: .rounded))
                    .foregroundStyle(AppTheme.ink)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.8)

                Text("Clear common AI-provenance, editing, location, camera, date, and attribution metadata from photos and videos.")
                    .font(.body)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.top, 34)

            ZStack {
                RoundedRectangle(cornerRadius: 36, style: .continuous)
                    .fill(AppTheme.brandGradient)
                    .shadow(color: AppTheme.rose.opacity(0.24), radius: 30, y: 18)
                VStack(spacing: 18) {
                    Image(systemName: "sparkles.rectangle.stack.fill")
                        .font(.system(size: 58, weight: .light))
                        .foregroundStyle(.white)
                    Text("Clean copies in a few taps")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Text("Your originals are never changed")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.82))
                }
            }
            .frame(height: 238)
            .accessibilityElement(children: .combine)

            pickerButton

            HStack(spacing: 8) {
                featurePill("On-device", icon: "iphone")
                featurePill("No account", icon: "person.crop.circle.badge.xmark")
                featurePill("Batch clean", icon: "square.stack.3d.up")
            }

            Text("AI Tag Remover clears file-level metadata. It cannot guarantee how another app labels or classifies content.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 12)
        }
    }

    private var selectedState: some View {
        VStack(spacing: 18) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .firstTextBaseline) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(model.allItemsClean ? "Ready to share" : "Ready to clean")
                            .font(.title2.weight(.bold))
                            .foregroundStyle(AppTheme.ink)
                        Text(selectionSummary)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button("Clear", role: .destructive) { model.clear() }
                        .font(.subheadline.weight(.semibold))
                        .disabled(model.isBusy)
                }

                Divider()
                ForEach(model.mediaItems) { item in
                    MediaRow(item: item)
                    if item.id != model.mediaItems.last?.id {
                        Divider().padding(.leading, 72)
                    }
                }
            }
            .cardStyle()

            if model.isImporting {
                ProgressView("Preparing your selection…")
                    .frame(maxWidth: .infinity)
                    .cardStyle()
            } else if model.isCleaning {
                Button {} label: {
                    primaryButtonLabel(title: "Cleaning…", icon: nil)
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(true)
            } else if model.cleanedURLs.isEmpty {
                Button {
                    Task { await model.cleanAll() }
                } label: {
                    primaryButtonLabel(
                        title: "Remove metadata",
                        icon: "sparkles"
                    )
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(model.isBusy)
            } else {
                VStack(spacing: 12) {
                    Button {
                        Task { await model.saveAll() }
                    } label: {
                        primaryButtonLabel(
                            title: model.isSaving ? "Saving…" : "Save clean copies",
                            icon: model.isSaving ? nil : "square.and.arrow.down"
                        )
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(model.isBusy)

                    Button {
                        model.isSharePresented = true
                    } label: {
                        Label("Share", systemImage: "square.and.arrow.up")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                    }
                    .buttonStyle(.bordered)
                    .buttonBorderShape(.roundedRectangle(radius: 18))
                    .disabled(model.isBusy)

                    if model.hasFailures {
                        Button {
                            Task { await model.cleanAll() }
                        } label: {
                            Label("Retry failed items", systemImage: "arrow.clockwise")
                                .font(.subheadline.weight(.semibold))
                        }
                        .disabled(model.isBusy)
                    }
                }
            }

            if !model.isBusy {
                pickerButton
            }
        }
    }

    private var pickerButton: some View {
        PhotosPicker(
            selection: $model.pickerItems,
            maxSelectionCount: 20,
            matching: .any(of: [.images, .videos]),
            preferredItemEncoding: .current
        ) {
            Label(
                model.mediaItems.isEmpty ? "Choose photos & videos" : "Choose a different batch",
                systemImage: "photo.on.rectangle.angled"
            )
            .font(.headline)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
        }
        .buttonStyle(AppActionButtonStyle(isPrimary: model.mediaItems.isEmpty))
        .disabled(model.isBusy)
        .accessibilityHint("Opens the system photo picker. Select up to 20 items.")
    }

    private var selectionSummary: String {
        let count = model.mediaItems.count
        let noun = count == 1 ? "item" : "items"
        if model.totalDetectedTags == 0 {
            return "\(count) \(noun) • no private tags detected"
        }
        let tagNoun = model.totalDetectedTags == 1 ? "tag" : "tags"
        return "\(count) \(noun) • \(model.totalDetectedTags) hidden \(tagNoun)"
    }

    private func featurePill(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.caption2.weight(.semibold))
            .foregroundStyle(AppTheme.plum)
            .lineLimit(1)
            .minimumScaleFactor(0.7)
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(AppTheme.rose.opacity(0.09), in: Capsule())
    }

    @ViewBuilder
    private func primaryButtonLabel(title: String, icon: String?) -> some View {
        HStack(spacing: 10) {
            if model.isBusy {
                ProgressView().tint(.white)
            } else if let icon {
                Image(systemName: icon)
            }
            Text(title)
        }
        .font(.headline)
        .frame(maxWidth: .infinity)
        .padding(.vertical, 17)
    }

    private var alertBinding: Binding<Bool> {
        Binding(
            get: { model.alertMessage != nil },
            set: { isPresented in
                if !isPresented { model.alertMessage = nil }
            }
        )
    }
}

private struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(.white)
            .background(AppTheme.brandGradient.opacity(configuration.isPressed ? 0.84 : 1))
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .shadow(color: AppTheme.rose.opacity(configuration.isPressed ? 0.08 : 0.20), radius: 16, y: 8)
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
    }
}

private struct AppActionButtonStyle: ButtonStyle {
    let isPrimary: Bool

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(isPrimary ? Color.white : AppTheme.plum)
            .background {
                if isPrimary {
                    AppTheme.brandGradient.opacity(configuration.isPressed ? 0.84 : 1)
                } else {
                    Color.white.opacity(configuration.isPressed ? 0.72 : 0.92)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(isPrimary ? Color.clear : AppTheme.plum.opacity(0.12), lineWidth: 1)
            }
            .shadow(color: isPrimary ? AppTheme.rose.opacity(0.20) : .clear, radius: 16, y: 8)
    }
}
