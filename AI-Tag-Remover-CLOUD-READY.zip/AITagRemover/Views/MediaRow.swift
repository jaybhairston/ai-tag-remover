import SwiftUI

struct MediaRow: View {
    let item: MediaItem

    var body: some View {
        HStack(spacing: 14) {
            thumbnail

            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 6) {
                    Image(systemName: item.kind.systemImage)
                    Text(item.kind.title)
                }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(AppTheme.ink)

                if item.originalReport.isClean {
                    Text("No private tags detected")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    Text("\(item.originalReport.totalTagCount) hidden tag\(item.originalReport.totalTagCount == 1 ? "" : "s") detected")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }

            Spacer(minLength: 8)
            statusView
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .combine)
    }

    private var thumbnail: some View {
        Group {
            if let image = item.thumbnail {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                ZStack {
                    AppTheme.brandGradient.opacity(0.16)
                    Image(systemName: item.kind.systemImage)
                        .foregroundStyle(AppTheme.plum)
                }
            }
        }
        .frame(width: 58, height: 58)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    @ViewBuilder
    private var statusView: some View {
        switch item.status {
        case .ready:
            Image(systemName: "circle.dashed")
                .foregroundStyle(.secondary)
                .accessibilityLabel("Ready to clean")
        case .cleaning:
            ProgressView()
                .accessibilityLabel("Cleaning")
        case .clean:
            Label("Clean", systemImage: "checkmark.circle.fill")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.green)
        case .saved:
            Label("Saved", systemImage: "checkmark.circle.fill")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.green)
        case .failed:
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.orange)
                .accessibilityLabel("Could not clean")
        }
    }
}
