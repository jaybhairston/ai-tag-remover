import SwiftUI

struct PrivacyView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    privacySection(
                        icon: "iphone.gen3",
                        title: "Everything stays on your iPhone",
                        body: "AI Tag Remover processes the photos and videos you select entirely on-device. They are never uploaded to us."
                    )
                    privacySection(
                        icon: "hand.raised.fill",
                        title: "No tracking",
                        body: "AI Tag Remover has no account, ads, analytics, tracking SDKs, or cloud service. We do not collect personal data."
                    )
                    privacySection(
                        icon: "doc.on.doc.fill",
                        title: "Your originals stay untouched",
                        body: "AI Tag Remover creates a new cleaned copy. It never edits or deletes the original in your photo library."
                    )
                    privacySection(
                        icon: "checkmark.seal.fill",
                        title: "Honest limits",
                        body: "AI Tag Remover rebuilds photos without source metadata and clears compatible video container metadata, then verifies readable tags. A platform may still classify content using information outside the file."
                    )
                }
                .padding(24)
            }
            .background(AppTheme.canvas.ignoresSafeArea())
            .navigationTitle("Privacy")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }

    private func privacySection(icon: String, title: String, body: String) -> some View {
        HStack(alignment: .top, spacing: 16) {
            Image(systemName: icon)
                .font(.title3.weight(.semibold))
                .foregroundStyle(AppTheme.plum)
                .frame(width: 30)
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.headline)
                    .foregroundStyle(AppTheme.ink)
                Text(body)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}
