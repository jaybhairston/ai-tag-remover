import AVFoundation
import Foundation
import ImageIO

enum MetadataInspector {
    static func inspectImage(at url: URL) throws -> MetadataReport {
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else {
            throw MediaCleaningError.unreadableImage
        }

        var report = MetadataReport()
        let frameCount = max(CGImageSourceGetCount(source), 1)

        for index in 0..<frameCount {
            let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as NSDictionary?

            addDictionary(
                properties?[kCGImagePropertyGPSDictionary],
                to: .location,
                report: &report
            )
            addImageDictionary(
                properties?[kCGImagePropertyExifDictionary],
                defaultCategory: .camera,
                safeKeyFragments: [
                    "pixelxdimension", "pixelydimension", "colorspace",
                    "componentsconfiguration", "flashpixversion", "exifversion"
                ],
                report: &report
            )
            addDictionary(
                properties?[kCGImagePropertyExifAuxDictionary],
                to: .camera,
                report: &report
            )
            addImageDictionary(
                properties?[kCGImagePropertyTIFFDictionary],
                defaultCategory: nil,
                safeKeyFragments: [
                    "orientation", "xresolution", "yresolution", "resolutionunit",
                    "compression", "photometricinterpretation"
                ],
                report: &report
            )
            addDictionary(
                properties?[kCGImagePropertyIPTCDictionary],
                to: .attribution,
                report: &report
            )
            addImageDictionary(
                properties?[kCGImagePropertyPNGDictionary],
                defaultCategory: nil,
                safeKeyFragments: ["gamma", "interlace", "srgb", "chromaticities"],
                report: &report
            )
            addDictionary(
                properties?[kCGImageProperty8BIMDictionary],
                to: .editing,
                report: &report
            )

            if let metadata = CGImageSourceCopyMetadataAtIndex(source, index, nil),
               let tags = CGImageMetadataCopyTags(metadata) as? [Any],
               !tags.isEmpty {
                report.add(.editing, count: tags.count)
            }
        }

        report.add(.editing, count: embeddedProvenanceMarkerCount(at: url))

        return report
    }

    static func inspectVideo(at url: URL) async throws -> MetadataReport {
        let asset = AVURLAsset(url: url)
        var items = try await asset.load(.metadata)
        let formats = try await asset.load(.availableMetadataFormats)

        for format in formats {
            items.append(contentsOf: try await asset.loadMetadata(for: format))
        }

        let tracks = try await asset.load(.tracks)
        for track in tracks {
            items.append(contentsOf: try await track.load(.metadata))
            let trackFormats = try await track.load(.availableMetadataFormats)
            for format in trackFormats {
                items.append(contentsOf: try await track.loadMetadata(for: format))
            }
        }

        var report = MetadataReport()
        var seenKeys = Set<String>()

        for item in items {
            let rawKey = [
                item.identifier?.rawValue,
                item.commonKey?.rawValue,
                item.key as? String
            ]
                .compactMap { $0 }
                .joined(separator: ".")
                .lowercased()

            guard !rawKey.isEmpty, seenKeys.insert(rawKey).inserted else { continue }
            report.add(category(for: rawKey))
        }

        return report
    }

    static func category(for rawKey: String) -> MetadataCategory {
        let key = rawKey.lowercased()
        if key.contains("location") || key.contains("gps") || key.contains("iso6709") {
            return .location
        }
        if key.contains("date") || key.contains("time") || key.contains("year") {
            return .captureDates
        }
        if key.contains("make") || key.contains("model") || key.contains("lens") || key.contains("camera") {
            return .camera
        }
        if key.contains("artist") || key.contains("author") || key.contains("copyright") ||
            key.contains("title") || key.contains("caption") || key.contains("description") ||
            key.contains("comment") {
            return .attribution
        }
        if key.contains("software") || key.contains("encoder") || key.contains("xmp") ||
            key.contains("creator") || key.contains("provenance") || key.contains("c2pa") {
            return .editing
        }
        return .other
    }

    private static func addDictionary(
        _ value: Any?,
        to category: MetadataCategory,
        report: inout MetadataReport
    ) {
        guard let dictionary = value as? NSDictionary, dictionary.count > 0 else { return }
        report.add(category, count: leafCount(in: dictionary))
    }

    private static func addImageDictionary(
        _ value: Any?,
        defaultCategory: MetadataCategory?,
        safeKeyFragments: [String],
        report: inout MetadataReport
    ) {
        guard let dictionary = value as? NSDictionary else { return }

        for (rawKey, rawValue) in dictionary {
            let key = String(describing: rawKey).lowercased()
            guard !safeKeyFragments.contains(where: { key.contains($0) }) else { continue }

            let detectedCategory = category(for: key)
            if detectedCategory != .other {
                report.add(detectedCategory, count: valueCount(rawValue))
            } else if let defaultCategory {
                report.add(defaultCategory, count: valueCount(rawValue))
            }
        }
    }

    private static func valueCount(_ value: Any) -> Int {
        if let dictionary = value as? NSDictionary {
            return max(leafCount(in: dictionary), 1)
        }
        if let array = value as? NSArray {
            return max(array.count, 1)
        }
        return 1
    }

    private static func leafCount(in dictionary: NSDictionary) -> Int {
        dictionary.allValues.reduce(0) { total, value in
            if let nested = value as? NSDictionary {
                return total + max(leafCount(in: nested), 1)
            }
            if let array = value as? NSArray {
                return total + max(array.count, 1)
            }
            return total + 1
        }
    }

    private static func embeddedProvenanceMarkerCount(at url: URL) -> Int {
        guard let data = try? Data(contentsOf: url, options: .mappedIfSafe) else { return 0 }
        let markers = ["c2pa", "jumb", "Content Credentials"]
        return markers.reduce(0) { count, marker in
            count + (data.range(of: Data(marker.utf8)) == nil ? 0 : 1)
        }
    }
}
