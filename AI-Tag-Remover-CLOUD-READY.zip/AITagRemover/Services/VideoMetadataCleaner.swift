import AVFoundation
import Foundation

enum VideoMetadataCleaner {
    static func clean(sourceURL: URL, outputDirectory: URL) async throws -> CleaningResult {
        let asset = AVURLAsset(url: sourceURL)
        let originalReport = try await MetadataInspector.inspectVideo(at: sourceURL)

        guard let exportSession = AVAssetExportSession(
            asset: asset,
            presetName: AVAssetExportPresetPassthrough
        ) else {
            throw MediaCleaningError.videoExportUnavailable
        }

        let compatibleTypes = await withCheckedContinuation { continuation in
            exportSession.determineCompatibleFileTypes { types in
                continuation.resume(returning: types)
            }
        }

        let fileType: AVFileType
        let fileExtension: String
        if compatibleTypes.contains(.mov) {
            fileType = .mov
            fileExtension = "mov"
        } else if compatibleTypes.contains(.mp4) {
            fileType = .mp4
            fileExtension = "mp4"
        } else {
            throw MediaCleaningError.unsupportedVideoFormat
        }

        let destinationURL = outputDirectory
            .appendingPathComponent("aitagremover-clean-\(UUID().uuidString)")
            .appendingPathExtension(fileExtension)

        exportSession.outputURL = destinationURL
        exportSession.outputFileType = fileType
        exportSession.shouldOptimizeForNetworkUse = true
        exportSession.metadata = []
        exportSession.metadataItemFilter = .forSharing()

        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            exportSession.exportAsynchronously {
                switch exportSession.status {
                case .completed:
                    continuation.resume()
                case .failed:
                    continuation.resume(throwing: MediaCleaningError.videoExportFailed(
                        exportSession.error?.localizedDescription ?? "Unknown export error."
                    ))
                case .cancelled:
                    continuation.resume(throwing: CancellationError())
                default:
                    continuation.resume(throwing: MediaCleaningError.videoExportFailed(
                        "The export ended unexpectedly."
                    ))
                }
            }
        }

        let outputReport = try await MetadataInspector.inspectVideo(at: destinationURL)
        guard outputReport.isClean else {
            try? FileManager.default.removeItem(at: destinationURL)
            throw MediaCleaningError.metadataVerificationFailed
        }

        return CleaningResult(outputURL: destinationURL, removedReport: originalReport)
    }
}
