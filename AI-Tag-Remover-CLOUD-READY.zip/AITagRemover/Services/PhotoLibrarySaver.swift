import Foundation
import Photos

enum PhotoLibrarySaver {
    static func save(_ items: [(url: URL, kind: MediaKind)]) async throws {
        let authorization = await requestAuthorization()
        guard authorization == .authorized || authorization == .limited else {
            throw MediaCleaningError.permissionDenied
        }

        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            PHPhotoLibrary.shared().performChanges {
                for item in items {
                    let request = PHAssetCreationRequest.forAsset()
                    let resourceType: PHAssetResourceType = item.kind == .image ? .photo : .video
                    request.addResource(with: resourceType, fileURL: item.url, options: nil)
                }
            } completionHandler: { success, error in
                if let error {
                    continuation.resume(throwing: error)
                } else if success {
                    continuation.resume()
                } else {
                    continuation.resume(throwing: MediaCleaningError.imageWriteFailed)
                }
            }
        }
    }

    private static func requestAuthorization() async -> PHAuthorizationStatus {
        await withCheckedContinuation { continuation in
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
                continuation.resume(returning: status)
            }
        }
    }
}
