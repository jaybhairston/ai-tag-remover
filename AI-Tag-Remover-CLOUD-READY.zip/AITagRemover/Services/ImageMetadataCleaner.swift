import Foundation
import ImageIO
import UniformTypeIdentifiers

enum ImageMetadataCleaner {
    static func clean(sourceURL: URL, destinationURL: URL) throws -> CleaningResult {
        guard let source = CGImageSourceCreateWithURL(sourceURL as CFURL, nil) else {
            throw MediaCleaningError.unreadableImage
        }
        guard let type = CGImageSourceGetType(source) else {
            throw MediaCleaningError.unsupportedImageFormat
        }

        let originalReport = try MetadataInspector.inspectImage(at: sourceURL)
        let cleanedData = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(
            cleanedData,
            type,
            CGImageSourceGetCount(source),
            nil
        ) else {
            throw MediaCleaningError.unsupportedImageFormat
        }

        preserveAnimationLoopIfNeeded(from: source, to: destination, type: type)

        let frameCount = CGImageSourceGetCount(source)
        for index in 0..<frameCount {
            let sourceProperties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as NSDictionary?
            let orientation = sourceProperties?[kCGImagePropertyOrientation] ?? 1
            var frameOptions: [CFString: Any] = [
                kCGImagePropertyOrientation: orientation,
                kCGImageDestinationLossyCompressionQuality: 1.0,
                kCGImageMetadataShouldExcludeGPS: true,
                kCGImageMetadataShouldExcludeXMP: true
            ]
            preserveAnimationTimingIfNeeded(
                from: sourceProperties,
                in: &frameOptions,
                type: type
            )

            guard let image = CGImageSourceCreateImageAtIndex(
                source,
                index,
                [kCGImageSourceShouldCache: false] as CFDictionary
            ) else {
                throw MediaCleaningError.unreadableImage
            }

            // Add decoded pixels to a brand-new container. Because no source metadata
            // is copied, unrecognized blocks such as JUMBF/C2PA are omitted too.
            CGImageDestinationAddImage(destination, image, frameOptions as CFDictionary)
        }

        guard CGImageDestinationFinalize(destination) else {
            throw MediaCleaningError.imageWriteFailed
        }

        try (cleanedData as Data).write(to: destinationURL, options: .atomic)
        try verify(destinationURL)
        return CleaningResult(outputURL: destinationURL, removedReport: originalReport)
    }

    private static func preserveAnimationLoopIfNeeded(
        from source: CGImageSource,
        to destination: CGImageDestination,
        type: CFString
    ) {
        guard type as String == UTType.gif.identifier,
              let properties = CGImageSourceCopyProperties(source, nil) as NSDictionary?,
              let gif = properties[kCGImagePropertyGIFDictionary] as? NSDictionary,
              let loopCount = gif[kCGImagePropertyGIFLoopCount]
        else { return }

        let safeProperties: [CFString: Any] = [
            kCGImagePropertyGIFDictionary: [
                kCGImagePropertyGIFLoopCount: loopCount
            ] as CFDictionary
        ]
        CGImageDestinationSetProperties(destination, safeProperties as CFDictionary)
    }

    private static func preserveAnimationTimingIfNeeded(
        from properties: NSDictionary?,
        in frameOptions: inout [CFString: Any],
        type: CFString
    ) {
        guard type as String == UTType.gif.identifier,
              let gif = properties?[kCGImagePropertyGIFDictionary] as? NSDictionary
        else { return }

        var timing: [CFString: Any] = [:]
        if let delay = gif[kCGImagePropertyGIFDelayTime] {
            timing[kCGImagePropertyGIFDelayTime] = delay
        }
        if let unclampedDelay = gif[kCGImagePropertyGIFUnclampedDelayTime] {
            timing[kCGImagePropertyGIFUnclampedDelayTime] = unclampedDelay
        }
        if !timing.isEmpty {
            frameOptions[kCGImagePropertyGIFDictionary] = timing as CFDictionary
        }
    }

    private static func verify(_ url: URL) throws {
        let report = try MetadataInspector.inspectImage(at: url)
        guard report.isClean else {
            try? FileManager.default.removeItem(at: url)
            throw MediaCleaningError.metadataVerificationFailed
        }
    }
}
