import AVFoundation
import Foundation
import UIKit

enum ThumbnailLoader {
    static func thumbnail(for url: URL, kind: MediaKind) async -> UIImage? {
        await Task.detached(priority: .utility) {
            switch kind {
            case .image:
                return UIImage(contentsOfFile: url.path)
            case .video:
                let asset = AVURLAsset(url: url)
                let generator = AVAssetImageGenerator(asset: asset)
                generator.appliesPreferredTrackTransform = true
                generator.maximumSize = CGSize(width: 360, height: 360)
                guard let image = try? generator.copyCGImage(at: .zero, actualTime: nil) else {
                    return nil
                }
                return UIImage(cgImage: image)
            }
        }.value
    }
}
