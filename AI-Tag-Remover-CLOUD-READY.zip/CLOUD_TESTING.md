# Free browser testing

This project includes a Codemagic workflow that compiles and tests the native
iOS app on a cloud Mac without Apple code signing. When the workflow succeeds,
download `AI-Tag-Remover-Appetize.zip` from the build artifacts and upload that
file to Appetize.

## 1. Put the project in a repository

Create a free private GitHub repository. Upload the unzipped contents of this
folder so that `codemagic.yaml` and `AITagRemover.xcodeproj` are both visible at
the top level of the repository. Do not upload the outer project ZIP as one
file, because Codemagic needs the unzipped source files.

## 2. Build it with Codemagic

1. Sign in to Codemagic with GitHub.
2. Select **Add application** and connect the private repository.
3. Choose **Codemagic YAML** when asked for the project configuration.
4. Select the `appetize-simulator` workflow and start the build.
5. Wait for the tests and build to pass.
6. Under **Artifacts**, download `AI-Tag-Remover-Appetize.zip`.

No Apple Developer membership, certificate, or provisioning profile is needed
for this simulator-only build.

## 3. Run it in Appetize

1. Open the Appetize **Apps** page and select **Upload App**.
2. Upload `AI-Tag-Remover-Appetize.zip` and choose iOS if prompted.
3. Start a session in the streamed iPhone simulator.
4. Use Appetize's media upload control to add sample JPG, PNG, GIF, or MP4 files
   to the simulator before testing the picker and cleaner.

Use sample media rather than private personal photos while evaluating any
third-party testing service.
