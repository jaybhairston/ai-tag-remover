# App Store listing draft

## Name

AI Tag Remover

## Subtitle

AI & private metadata cleaner

## Promotional text

Clear common file-level AI provenance plus hidden location, camera, date, editing, and attribution metadata—entirely on your iPhone.

## Description

Your photo can reveal more than what is in the frame.

AI Tag Remover creates a clean copy of selected photos and videos by removing common file-level AI provenance and readable metadata such as precise location, capture dates, camera and lens details, captions, author information, editing-software tags, and XMP data.

Simple by design:

• Choose up to 20 photos and videos  
• See whether hidden tags were detected  
• Remove and verify metadata on your iPhone  
• Save clean copies or share them right away

Private by design:

• Everything happens on-device  
• Your originals are never changed  
• No account  
• No ads  
• No analytics or tracking  
• No cloud upload

AI Tag Remover supports common formats available through the iOS photo picker, including HEIC, JPEG, PNG, GIF, TIFF, MOV, and MP4 when supported by the device.

AI Tag Remover clears file-level metadata. It does not remove visible or invisible pixel-level watermarks. Other apps and services may use separate signals or policies, so metadata removal does not guarantee how a platform will label a post.

## Keywords

AI tags,metadata,C2PA,EXIF,GPS,XMP,privacy,photo cleaner,video cleaner,location remover

## Category

Photo & Video

## Age rating

4+

## Pricing

Free for version 1.0. No in-app purchases.

## URLs to replace before submission

- Support URL: `https://YOUR-DOMAIN.example/aitagremover/support`
- Privacy Policy URL: `https://YOUR-DOMAIN.example/aitagremover/privacy`
- Marketing URL (optional): `https://YOUR-DOMAIN.example/aitagremover`
