# Notes for App Review

AI Tag Remover creates metadata-clean copies of user-selected photos and videos. No login, account, payment, or network connection is required.

## Review flow

1. Tap **Choose photos & videos**.
2. Select one or more items with the system photo picker.
3. Tap **Remove metadata**.
4. The app creates a local copy and re-inspects it before displaying **Clean**.
5. Tap **Save clean copies** to test add-only Photos access, or **Share** to open the system share sheet.

The app never modifies or deletes the original. It uses the out-of-process photo picker and requests only add-only Photos permission when the reviewer explicitly saves output.

There is no demo account. The app contains no third-party SDKs, analytics, advertising, tracking, or network service. App Privacy answers should be **Data Not Collected**.

For photos, the app writes decoded visual content into a new container so source metadata and common file-level provenance blocks are not copied. For videos, it clears compatible descriptive/container metadata. The app then re-inspects readable metadata before reporting success. It makes no promise about how third-party services independently classify uploaded content.
