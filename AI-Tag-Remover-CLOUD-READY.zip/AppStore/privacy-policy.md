# AI Tag Remover Privacy Policy

**Effective date: September 3, 2026**

AI Tag Remover is designed to process photos and videos privately on your device.

## Data collection

AI Tag Remover does not collect, transmit, sell, or share personal data. The app has no user accounts, analytics, advertising, tracking technology, or remote server connection.

## Photos and videos

You choose items through Apple's system photo picker. AI Tag Remover processes those items locally on your device to create metadata-clean copies. Your original items are not modified or deleted. Temporary working copies are stored only in the app's temporary storage and may be removed by the app or operating system.

If you choose **Save clean copies**, AI Tag Remover requests add-only Photos permission and writes the cleaned copies to your photo library. AI Tag Remover does not request general read access to your library. If you choose **Share**, Apple's share sheet sends the copy only to the destination you select.

## Data retention

AI Tag Remover does not retain user data on a server. Temporary local files are cleared when you clear the current batch and are also subject to automatic cleanup by iOS.

## Children

AI Tag Remover does not knowingly collect personal information from anyone, including children.

## Changes

If this policy changes, the effective date above will be updated. A change that introduces data collection will be disclosed in the app and in App Store privacy information before it takes effect.

## Contact

Questions about privacy can be sent to: **REPLACE-WITH-YOUR-SUPPORT-EMAIL**
