# AI Tag Remover 1.0 release checklist

## Owner inputs required

- [ ] Reserve **AI Tag Remover** in App Store Connect and complete a final trademark check.
- [ ] Choose the legal seller name (individual or organization).
- [ ] Enroll in/confirm the Apple Developer Program.
- [ ] Set the Xcode signing team and final bundle identifier.
- [ ] Replace the support email in the privacy and support pages.
- [ ] Host the privacy and support pages on public HTTPS URLs.
- [ ] Replace the placeholder URLs in `metadata.md`.

## Build and QA on a Mac

- [ ] Open with the current public Xcode release and resolve any new SDK warnings.
- [ ] Run all unit tests on an iOS 17 simulator and the latest iOS simulator.
- [ ] Complete every row in the README real-device matrix.
- [ ] Test low-storage behavior with at least one large 4K video.
- [ ] Test portrait orientation, Live Photo selection behavior, HDR HEIC, and Dolby Vision video.
- [ ] Confirm the 1024×1024 icon has no alpha channel and looks correct under iOS icon masks.
- [ ] Run Accessibility Inspector and VoiceOver.
- [ ] Archive a Release build with no analyzer errors.

## App Store Connect

- [ ] Create the app record and SKU.
- [ ] Upload the archived build.
- [ ] Set category to **Photo & Video**, age rating to **4+**, and price to **Free**.
- [ ] Set App Privacy to **Data Not Collected** only after confirming the shipped binary still has no analytics/network SDK.
- [ ] Add privacy policy and support URLs.
- [ ] Upload 6.9-inch iPhone screenshots captured from the final build.
- [ ] Paste the prepared description, subtitle, keywords, and review notes.
- [ ] Complete export-compliance questions (the app does not implement custom encryption).
- [ ] Select the uploaded build and submit for review.
