# AI Tag Remover Support

## Quick help

**Why is the clean copy dated today in Photos?**  
Capture timestamps are metadata. AI Tag Remover removes them from the file, so Photos treats the cleaned copy as newly added.

**Does AI Tag Remover change my original?**  
No. AI Tag Remover creates a separate copy and never edits or deletes the original.

**Does AI Tag Remover upload my photos or videos?**  
No. Processing is entirely on-device.

**Why did an item fail?**  
AI Tag Remover only marks an item clean after verifying the output. A damaged file, unsupported codec, protected media, or low free storage can prevent a verified export.

**Will this prevent every “AI” label?**  
No app can promise that. AI Tag Remover removes file-level metadata and common provenance markers; platforms may use other signals or policies.

## Contact

Support email: **REPLACE-WITH-YOUR-SUPPORT-EMAIL**

When reporting a problem, include your iPhone model, iOS version, media format, and the exact message shown by AI Tag Remover. Do not send private media unless you intentionally choose to.
