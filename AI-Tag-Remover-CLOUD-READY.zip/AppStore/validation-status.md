# Validation status — September 3, 2026

## Passed in this workspace

- Xcode project graph: 55 objects defined; all identifiers are hexadecimal, unique, and resolved.
- Shared scheme and privacy manifest: valid XML.
- Asset catalogs: valid JSON.
- App icon: opaque RGB PNG, 1024×1024, no alpha pixel format.
- Source inventory: 15 app Swift files plus one test file, all referenced by the project.
- Privacy preflight: no networking, web-view, analytics, or tracking API references in the app target.
- Release copy: 29/30 subtitle characters and 87/100 keyword characters.
- App source: no TODOs, placeholder URLs, placeholder emails, or unfinished user-facing copy.

## Automated tests included

- A JPEG fixture containing GPS, EXIF, TIFF, IPTC, and a file-level `c2pa` marker is rebuilt and verified clean while retaining dimensions.
- Metadata-key classification is checked for location, dates, camera data, attribution, and AI/editing provenance.
- A generated QuickTime fixture with container metadata is exported, re-inspected, checked clean, and checked for playable duration.

## Still required on a Mac

This workspace is Windows and cannot run Apple's Xcode, iOS Simulator, code signing, or App Store upload tools. Before submission, run the included tests in current Xcode, complete the README real-device media matrix, and archive the Release configuration. Do not describe the app as fully tested or submission-ready until those checks pass.
