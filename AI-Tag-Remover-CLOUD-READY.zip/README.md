# AI Tag Remover

AI Tag Remover is a small, privacy-first iOS app that creates metadata-clean copies of selected photos and videos. Processing happens on-device, originals remain untouched, and the app contains no account, analytics, ads, or network layer.

## MVP features

- Select up to 20 photos and videos with Apple's system photo picker.
- Preserve current image formats, including HEIC, JPEG, PNG, GIF, and TIFF when supported by iOS.
- Remove readable GPS, EXIF, IPTC, TIFF, XMP, Photoshop, common file-level AI provenance markers, and compatible QuickTime/container metadata.
- Rebuild photos in a new container from decoded visual content so unrecognized source metadata blocks are not copied; encode lossy formats once at maximum quality.
- Remux compatible videos without re-encoding and replace their descriptive metadata.
- Verify the cleaned output before presenting it as clean.
- Save copies to Photos or share them directly.
- VoiceOver labels, Dynamic Type, light/dark compatible system controls, and no unnecessary photo-library read permission.

## Open and run

Requirements: a Mac with Xcode 16 or later, an iPhone or iOS 17+ simulator, and an Apple Developer account for device/App Store distribution.

1. Open `AITagRemover.xcodeproj` in Xcode.
2. Select the **AITagRemover** target, then **Signing & Capabilities**.
3. Choose your team and replace `com.aitagremover.ios` if that bundle identifier is unavailable.
4. Run the **AITagRemover** scheme on an iPhone simulator.
5. Run tests with **Product > Test** (`⌘U`).
6. Repeat the manual test matrix below on at least one real iPhone before submission.

## Release test matrix

| Case | Expected result |
|---|---|
| HEIC portrait with GPS/date/camera tags | Appearance and orientation match; inspected clean copy has no readable private tags |
| JPEG edited by a desktop/AI tool with EXIF/XMP | Clean copy verifies and shares successfully |
| PNG with text/XMP chunks | Clean copy verifies and remains visually equivalent |
| Animated GIF | Frame count remains unchanged and metadata verifies clean |
| Dolby Vision/HEVC iPhone video | Passthrough export completes; playback, audio, orientation, and HDR appearance are checked on-device |
| MP4 with title/location metadata | Clean copy plays and descriptive metadata verifies clean |
| Batch of 20 mixed items | UI stays responsive; every item reports its own success/failure |
| Deny add-only Photos permission | Friendly recovery message appears; Share remains available |
| VoiceOver + largest Dynamic Type | All actions are named and usable without clipped critical text |
| Airplane mode | Every feature still works |

## Important product limit

AI Tag Remover removes file-level metadata and common provenance markers, then verifies readable tags with Apple's media frameworks. It does not target visible or invisible pixel-level watermarks and cannot guarantee whether a social platform will label content based on upload history, platform-side signals, its own classifier, or posting disclosures.

## Submission

Use the prepared copy and review notes in `AppStore/`. Before archiving, replace the privacy/support URL placeholders, confirm the final name and bundle ID are available in App Store Connect, set the signing team, and complete the real-device test matrix.

See `AppStore/validation-status.md` for the checks completed here and the Xcode checks that remain.
